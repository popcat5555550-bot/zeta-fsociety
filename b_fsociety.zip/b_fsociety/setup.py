from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zeta-fsociety",
    version="0.3.1",
    author="Zeta",
    description="Хакерская библиотека для сетевых инструментов",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/zeta-fsociety",
    packages=find_packages(),
    install_requires=[
        "netifaces2",
        "requests",
        "python-nmap",
        "python-whois"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)